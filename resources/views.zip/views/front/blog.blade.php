@extends('front.layout')
@section('content')
    <!-- page-header-start -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
                    <div class="page-section">
                        <h1 class="page-title">Blog-Single</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-breadcrumb">
        <div class="container">
            <div class="row">
                <div class=" col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li>Blog</li>
                        <li>Blog-single</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- page-header-close -->
    <!-- blog-section start -->
    <div class="space-medium">
        <div class="container">
            <div class="row">
                <!-- post-one-start -->
                <div class=" col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="post-block">
                        <div class="post-img"><img src="{{asset('template/images/slider1.jpg')}}" alt="Tour and Travel Agency - Responsive Website Template" class="img-responsive" style="background-size: cover;"></div>
                        <div class="post-sticky"> <i class="fa fa-thumb-tack"></i> </div>
                        <div class="post-content">
                            <div>
                                <h1 class="post-title">Best Budget Destination for Couple</h1>
                            </div>
                            <div class="meta"> <span class="meta-date">Posted on March 5, 2017 </span> <span class="meta-author">by <a href="#">Timothy Cooper</a></span> </div>
                        </div>
                    </div>
                </div>
                <div class=" col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <p>Pellentesque habitant morbi tristique senectus etnetus et malesuada fames acturpis egestas morbi utenim idest aliquam ornare velim eget nisi vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere.</p>
                    <p>Cras quis tincidunt enim morbi etneque tempor sapien viverra condimentum maecenas gravida dapibus feugia duis cursus atnisi at facilisis morbi vulputate quamat auctor massa eleifend eultrices neque euipsum pharetra imperdiet fonec vel mauris aliquet sollicitici udin ligula sed consequat leo proin ornare gravida congue morbi eget lacus vitae dolor suscipit sagittis mauris. </p>
                    <p>Aenean laoreet lacinia ipsum, nec porta neque maximus quis. In purus dui, congue vel felis in, blandit gravida augue. Suspendisse mattis imperdiet leo, sed lobortis mi rhoncus eu. Praesent pulvinar fermentum pretium. In quis tellus ut ligula condimentum tempor. Nulla ornare blandit libero id pretium. Morbi luctus nunc et nisl maximus viverra. Donec ultrices suscipit egestas. Pellentesque ut imperdiet lorem. Curabitur lobortis, sem a imperdiet fringa ligula, eu porta lacus ipsum ut nulla. Integer porttitor,erra diam orci ut lacus.</p>
                    <p class="blockquote">"Nullam rutrum viverra leo, et egestas nibh malesuada quis. Nam placerat euismod quam, nec ullamcorper odio. Maecenas feugiat risus sed aliqulentesque aliquet leo eros, quis interdum leo faucibus eget."</p>
                    <img src="{{asset('template/images/multi6.jpg')}}" alt="" class="align-left">
                    <p>Morbi et neque tempor sapien viverra condimentu mecenas gravida dapibus feugiat duis cursus atnisi at Integer tincidunt varius eleifend. Vestibulum dapibus ac ante nec feugiat.facilisis morbi vulpu tate quamt auctor massa eleifend pharetra imperdiet. </p>
                    <p>Onteger eu facilisis lectus at condimentum velit pellentesque at ipsum eros mesent lectus tellus mollis eget sem quis mattis hendrerit elit vivamus rutrum justo sed porta ullamcoreros est sit amet libero. Nulla quis facilisis sem. Sed elementum maximus quam eu commodo. Curabitur maximus tincidunt purus, in pulvinar lorem euismod at. Morbi porttitor luctus justo id sollicitudin. Cras non est eget lectus consectetur finibus sed eu arcu. Quisque suscipit, urna et varius bibendum, tortor urna vehicula lectus, vitae commodo turpis nisi non quam.</p>
                    <div class="post-navigation mb30 mt80">
                        <div class="row">
                            <div class="nav-links">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"> <a href="#" class=" prev-link mb30">Prev Post</a>
                                    <h4 class="previous-next-title"><a href="#">Amazing place to visit</a></h4>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class=" nav-next text-right"><a href="#" class="next-link mb30">Next Post</a>
                                        <h4 class="previous-next-title"><a href="#">Travel Photography Tips</a></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Author post start-->
                    <div class="author-block">
                        <div class="row">
                            <div class="author-post">
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                    <div class="author-img">
                                        <a href="#"><img src="{{asset('template/images/testimonial-user-img-2.jpg')}}" alt="Tour and Travel Agency - Responsive Website Template" class="img-circle"></a>
                                    </div>
                                </div>
                                <div class="col-lg-9 col-md-9 col-sm-6 col-xs-12">
                                    <div class="author-post-content">
                                        <h4 class="author-title"><a href="#" class="title">Jorge McNeal</a></h4>
                                        <span class="author-meta">Author</span>
                                        <p class="author-text"> Pellentesque rhoncus aliquet sem vitae tristique. Fusce blandit massa vitae elementum tinciduntris lorem justo feugiat ac luctus nec faucibus ac semhasellus suscipit orci nisi.</p>
                                        <div class="author-post-btn"><a href="#" class="btn btn-primary btn-lg">view all post</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Author post close-->
                    <div class="related-block">
                        <div class="row">
                            <div class=" col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <h2>Related Post</h2>
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                        <div class="related-post">
                                            <div class="related-img">
                                                <a href="blog-single.html" class="imghover"><img src="{{asset('template/images/testimonial-img-3.jpg')}}" alt="Tour and Travel Agency - Responsive Website Template" class="img-responsive"></a>
                                            </div>
                                            <div class="related-post-content">
                                                <h2><a href="#" class="title">The Ultimate singapore to do list</a></h2>
                                                <span class="meta-categories">In<a href="#" class="title">"Travel"</a></span></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                        <div class="related-post">
                                            <div class="related-img">
                                                <a href="blog-single.html" class="imghover"><img src="{{asset('template/images/testimonial-img-2.jpg')}}" alt="Tour and Travel Agency - Responsive Website Template" class="img-responsive"></a>
                                            </div>
                                            <div class="related-post-content">
                                                <h2 class="related-title"><a href="#" class="title">Survival Tips While Exploring
                        the World!</a></h2>
                                                <span class="meta-categories">In<a href="#">"Travel"</a></span></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                        <div class="related-post">
                                            <div class="related-img">
                                                <a href="blog-single.html" class="imghover"> <img src="{{asset('template/images/testimonial-img-1.jpg')}}" alt="Tour and Travel Agency - Responsive Website Template" class="img-responsive"> </a>
                                            </div>
                                            <div class="related-post-content">
                                                <h2><a href="#" class="title">The Ultimate singapore to do list</a></h2>
                                                <span class="meta-categories">In<a href="#" class="title">"Travel"</a></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--comments start-->
                    <div class="comment-area">
                        <div class="row">
                            <div class=" col-lg-12 col-md-12">
                                <div class="comment-title">
                                    <h2>(4)Comments</h2>
                                    <ul class="comment-list">
                                        <li>
                                            <div class="comment-author"><img src="{{asset('template/images/testimonial-img-3.jpg')}}"  style="height:60px; width:60px;" alt="Tour and Travel Agency - Responsive Website Template" class="img-circle"></div>
                                            <div class="comment-info">
                                                <h4 class="user-title">Cassandra Craft</h4>
                                                <div class="meta">
                                                    <div class="comment-meta-date">31 March, 2017</div>
                                                </div>
                                                <div class="comment-content">
                                                    <p>Curabieet sitamet purus sed vestibulu ullam cursus, lacus eget pharetra accumsan ante metussent ultrices massa ligula. Duis mollis ultrices lectus a placerat. Fusce pretium dui sed dius natoque penatibus et magnis dis parturiet the iaculis etiam.</p>
                                                </div>
                                                <a href="#" class="reply-link">Reply</a> </div>
                                        </li>
                                    </ul>
                                     <ul class="comment-list">
                                        <li>
                                            <div class="comment-author"><img src="{{asset('template/images/testimonial-img-2.jpg')}}"  style="height:60px; width:60px;" alt="Tour and Travel Agency - Responsive Website Template" class="img-circle"></div>
                                            <div class="comment-info">
                                                <h4 class="user-title">Stephen McDaniel</h4>
                                                <div class="meta"> <span class="comment-meta-date">28 March, 2017</span></div>
                                                <div class="comment-content">
                                                    <p>Praesent ultrices massa ligula. Duis mollis ultrices lectus a placerat. Fusce pretium dui sed diam faucibu varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Phasellus mauris odio.</p>
                                                </div>
                                                <a href="#" class="reply-link">Reply</a> </div>
                                            <ul class="comment-list childern">
                                                <li>
                                                    <div class="comment-author"><img src="{{asset('template/images/testimonial-img-1.jpg')}}"  style="height:60px; width:60px;" alt="Tour and Travel Agency - Responsive Website Template" class="img-circle"></div>
                                                    <div class="comment-info">
                                                        <h4 class="user-title">Lester Sanders</h4>
                                                        <div class="meta"> <span class="comment-meta-date">10 March, 2017</span></div>
                                                        <div class="comment-content">
                                                            <p>Suscipit metus quis pharetra etpeisgetreruis mollis ultrices lectused diam faucibus celerci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Phasellus mrateget the iaculis etiam.</p>
                                                        </div>
                                                        <a href="#" class="reply-link">Reply</a> </div>
                                            </ul>
                                            </li>
                                    </ul>
                                    <ul class="comment-list">
                                        <li>
                                            <div class="comment-author"><img src="{{asset('template/images/testimonial-img-3.jpg')}}"  style="height:60px; width:60px;" alt="Tour and Travel Agency - Responsive Website Template" class="img-circle"></div>
                                            <div class="comment-info">
                                                <h4 class="user-title">Vicki Bouknight</h4>
                                                <div class="meta"> <span class="comment-meta-date">18 March, 2017</span></div>
                                                <div class="comment-content">
                                                    <p>Praesent ultrices massa ligula. Duis mollis ultrices lectus a placerat. Fusce pretium dui sed diam faucibus scelerisque. Orci varius natoquscetur rius mauris odio, dictum eu elementum ac, pretium eu dui.</p>
                                                </div>
                                                <a href="#" class="reply-link">Reply</a></div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--comments close-->
                    <div class="leave-comments">
                        <h2 class="comment-title">Leave A Reply</h2>
                        <form>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                                    <div class="form-group">
                                        <label class="control-label" for="textarea">Comments</label>
                                        <textarea class="form-control" id="textarea" name="textarea" rows="6"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="form-group">
                                        <label class="control-label" for="name">Name</label>
                                        <input id="name" name="name" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="form-group">
                                        <label class="control-label" for="email">Email</label>
                                        <input id="email" name="email" type="email" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                                    <div class="form-group">
                                        <label class="control-label" for="website">Website</label>
                                        <input id="website" name="website" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                                    <div class="form-group">
                                        <button id="singlebutton" name="singlebutton" class="btn btn-primary btn-sm">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/menumaker.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/jquery.sticky.js"></script>
    <script type="text/javascript" src="js/sticky-header.js"></script>

@endsection
