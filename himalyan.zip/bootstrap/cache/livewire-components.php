<?php return array (
  'admin.destination-list' => 'App\\Http\\Livewire\\Admin\\DestinationList',
  'admin.packages' => 'App\\Http\\Livewire\\Admin\\Packages',
);